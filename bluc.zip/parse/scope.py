class Scope(object):
    pass